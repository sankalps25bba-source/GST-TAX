
import streamlit as st
import pandas as pd
import re

# ----------------------------------
# PAGE CONFIGURATION
# ----------------------------------

st.set_page_config(
    page_title="GST Rate Finder India",
    page_icon="🧾",
    layout="centered"
)

# ----------------------------------
# APPLICATION DESIGN
# ----------------------------------

st.markdown("""
<style>
.block-container {
    max-width: 950px;
    padding-top: 2rem;
}
.main-title {
    background: linear-gradient(120deg, #102a43, #176b87);
    padding: 25px;
    border-radius: 15px;
    color: white;
    text-align: center;
}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="main-title">
<h1>🧾 GST RATE FINDER</h1>
<h4>Indian Goods and Services Tax Information System</h4>
<p>Search goods • Check HSN • Find applicable GST rates</p>
</div>
""", unsafe_allow_html=True)

st.write("")

# ----------------------------------
# GST REFERENCE DATABASE
# ----------------------------------

data = [
    {
        "goods_name": "Rice (pre-packaged and labelled)",
        "aliases": "rice|packaged rice|labelled rice",
        "hsn_code": "1006",
        "gst_rate": 5,
        "status": "Taxable",
        "description": "Cereals under tariff heading 1006.",
        "conditions": "Applies to rice pre-packaged and labelled as specified in the GST rate entry.",
        "source": "Notification 9/2025-Central Tax (Rate), Schedule I, entry 51."
    },
    {
        "goods_name": "Rice (other than pre-packaged and labelled)",
        "aliases": "loose rice|unpackaged rice|open rice",
        "hsn_code": "1006",
        "gst_rate": 0,
        "status": "Exempt",
        "description": "Rice supplied under the relevant exemption entry.",
        "conditions": "Verify packaging, labelling and exemption conditions.",
        "source": "Notification 10/2025-Central Tax (Rate)."
    },
    {
        "goods_name": "Fresh milk",
        "aliases": "fresh milk|ordinary milk|unprocessed milk",
        "hsn_code": "0401",
        "gst_rate": 0,
        "status": "Exempt",
        "description": "Fresh milk other than UHT milk.",
        "conditions": "Do not use this classification for UHT milk or milk products.",
        "source": "Notification 10/2025-Central Tax (Rate)."
    },
    {
        "goods_name": "UHT milk",
        "aliases": "ultra high temperature milk|long life milk",
        "hsn_code": "0401",
        "gst_rate": 5,
        "status": "Taxable",
        "description": "Ultra High Temperature milk.",
        "conditions": "Confirm the exact tariff description.",
        "source": "Notification 9/2025-Central Tax (Rate), Schedule I, entry 7."
    },
    {
        "goods_name": "Laptop",
        "aliases": "laptops|notebook computer|portable computer",
        "hsn_code": "8471",
        "gst_rate": 18,
        "status": "Taxable",
        "description": "Automatic data processing machines and units.",
        "conditions": "Confirm the exact HSN subheading and product configuration.",
        "source": "CBIC GST rate schedule."
    },
    {
        "goods_name": "Cement",
        "aliases": "portland cement|ordinary portland cement|cement bags",
        "hsn_code": "2523",
        "gst_rate": 18,
        "status": "Taxable",
        "description": "Cement under heading 2523.",
        "conditions": "Confirm the exact cement type and tariff entry.",
        "source": "Notification 9/2025-Central Tax (Rate); PIB GST rationalisation factsheet."
    }
]

df = pd.DataFrame(data)

# ----------------------------------
# SEARCH FUNCTION
# ----------------------------------

def normalize(text):
    return re.sub(
        r"[^a-z0-9 ]",
        " ",
        str(text).lower()
    ).strip()

def search_goods(query):

    query = normalize(query)

    results = []

    for _, row in df.iterrows():

        terms = [row["goods_name"]]
        terms += row["aliases"].split("|")

        for term in terms:

            term = normalize(term)

            if query == term or query in term or term in query:
                results.append(row)
                break

    return pd.DataFrame(results)

# ----------------------------------
# USER SEARCH SECTION
# ----------------------------------

st.subheader("Search GST Rates")

query = st.text_input(
    "Enter the name of goods:",
    placeholder="Example: Rice, Laptop, Fresh milk, Cement"
)

if query.strip():

    results = search_goods(query)

    if results.empty:

        st.error("Goods not found in the reference database.")

        st.info(
            "Try another product name. An unlisted product "
            "must not be assumed to be GST exempt."
        )

    else:

        st.success(
            str(len(results)) + " matching classification(s) found."
        )

        for _, item in results.iterrows():

            with st.container(border=True):

                st.subheader(item["goods_name"])

                st.write(item["description"])

                col1, col2 = st.columns(2)

                col1.metric(
                    "HSN Code",
                    item["hsn_code"]
                )

                col2.metric(
                    "GST Rate",
                    str(item["gst_rate"]) + "%"
                )

                if item["status"] == "Taxable":
                    st.success("GST Applicable: Taxable")

                elif item["status"] == "Exempt":
                    st.info("GST Not Applicable: Exempt")

                else:
                    st.warning("Nil-rated")

                # ----------------------------------
                # TAX BREAKDOWN
                # ----------------------------------

                rate = float(item["gst_rate"])

                st.write("**GST Rate Breakdown**")

                col1, col2, col3 = st.columns(3)

                col1.metric("CGST", f"{rate/2:g}%")
                col2.metric("SGST", f"{rate/2:g}%")
                col3.metric("IGST", f"{rate:g}%")

                st.write("**Conditions:**")
                st.write(item["conditions"])

                st.caption(
                    "Source reference: " + item["source"]
                )

# ----------------------------------
# EXAMPLE PRODUCTS
# ----------------------------------

st.divider()

st.subheader("Example Searches")

st.write(
    "Rice | Laptop | Fresh milk | UHT milk | Cement"
)

# ----------------------------------
# OFFICIAL SOURCES
# ----------------------------------

st.divider()

st.subheader("Official GST Sources")

sources = {
    "CBIC GST Goods and Services Rates":
    "https://cbic-gst.gov.in/hindi/gst-goods-services-rates.html",

    "GST Council Central Tax Rate Notifications":
    "https://gstcouncil.gov.in/cgst-rate-notification",

    "PIB 56th GST Council FAQ":
    "https://www.pib.gov.in/PressReleasePage.aspx?PRID=2168426&lang=2&reg=48",

    "PIB Cement GST Rate Factsheet":
    "https://www.pib.gov.in/FactsheetDetails.aspx?ModuleId=16&id=150297&lang=1&reg=1",

    "Notification 9/2025":
    "https://taxinformation.cbic.gov.in/view-pdf/1010436/ENG/Notifications",

    "Notification 10/2025":
    "https://taxinformation.cbic.gov.in/view-pdf/1010437/ENG/Notifications"
}

for name, url in sources.items():

    st.markdown(f"- [{name}]({url})")

# ----------------------------------
# DISCLAIMER
# ----------------------------------

st.divider()

st.warning("""
DISCLAIMER:

This application is developed for educational and project purposes.

The database contains a limited demonstration dataset.
It is not a complete official GST database or a live CBIC connection.

Actual GST applicability depends on the exact HSN classification,
product description, composition, packaging, labelling, supply
conditions and applicable notifications.

Always verify the latest official GST notifications before
using any result for commercial transactions or tax returns.
""")

st.caption("GST Rate Finder | India | Educational Prototype")
